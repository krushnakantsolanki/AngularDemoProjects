# Angular_Testing
Unit and Integration testing in Angular

#Step 1:-  Download the above source code.There are two folder one is for Unit testing and other one is for integration testing

#Step 2:-  Install all required npm packages by running npm install from the command line in the respective project root folder (where the package.json is located).

#Step 3:-  Start the application by running ng test from the command line in the project root folder.



